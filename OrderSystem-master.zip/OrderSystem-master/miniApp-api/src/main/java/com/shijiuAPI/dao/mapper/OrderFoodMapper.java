package com.shijiuAPI.dao.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiuAPI.pojo.OrderFood;

public interface OrderFoodMapper  extends BaseMapper<OrderFood> {
}
