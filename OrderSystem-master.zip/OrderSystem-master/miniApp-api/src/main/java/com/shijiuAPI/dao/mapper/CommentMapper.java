package com.shijiuAPI.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiuAPI.vo.Comment;

public interface CommentMapper extends BaseMapper<Comment> {
}
