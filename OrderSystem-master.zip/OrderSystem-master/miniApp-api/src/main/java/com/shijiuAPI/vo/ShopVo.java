package com.shijiuAPI.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShopVo {
    // Shop id
//    @TableId(type = IdType.AUTO)
    Integer id;
    // Owner id
    Integer userId;
    // Owner name
    String ownerName;

    String shopName;

    String shopSrc;
    // Shop contact information
    String phone;
    // Shop summary
    String summary;
    // Shop rating, controlled by admin
    Integer stars;
}
