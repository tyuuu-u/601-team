package com.shijiuAPI.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shijiuAPI.pojo.Food;

public interface FoodService extends IService<Food> {
}
