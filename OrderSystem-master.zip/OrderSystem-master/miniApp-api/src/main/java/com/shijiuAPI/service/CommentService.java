package com.shijiuAPI.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shijiuAPI.vo.Comment;

public interface CommentService extends IService<Comment> {
}
