package com.shijiuAPI.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderParam {
    //The order parameters passed from the front end include: user name, phone number, address, {foodid, shopid, count}

    private String name;

    private String address;

    private String phone;

    private List<OrderFoodParam> orderFoods;
}
