package com.shijiuAPI.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiuAPI.pojo.Order;

public interface OrderMapper extends BaseMapper<Order> {
}
