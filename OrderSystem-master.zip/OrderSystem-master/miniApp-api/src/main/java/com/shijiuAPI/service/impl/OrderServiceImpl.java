package com.shijiuAPI.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.shijiuAPI.config.UserThreadLocal;
import com.shijiuAPI.dao.mapper.OrderMapper;
import com.shijiuAPI.pojo.Food;
import com.shijiuAPI.pojo.Order;
import com.shijiuAPI.pojo.OrderFood;
import com.shijiuAPI.service.FoodService;
import com.shijiuAPI.service.OrderFoodService;
import com.shijiuAPI.service.OrderService;
import com.shijiuAPI.service.ShopService;
import com.shijiuAPI.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Slf4j
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements OrderService {

    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private OrderFoodService orderFoodService;
    @Autowired
    private ShopService shopService;
    @Autowired
    private FoodService foodService;
    @Override
    public Result createOrder(OrderParam orderParam) {
//         orderFoods=[
//         OrderFoodParam(id=24, shopId=2, count=1),
//         OrderFoodParam(id=3, shopId=1, count=1),
//         OrderFoodParam(id=1, shopId=1, count=2),
//         ])
        Set<Integer> shopIdSet = new HashSet<>();
        for (OrderFoodParam orderFood : orderParam.getOrderFoods()) {
            
            shopIdSet.add(orderFood.getShopId());
        }
        log.info("OrderServiceImpl-createOrder-shopIdSet{}",shopIdSet);
        //Generate an order for each store
        for (Integer shopId : shopIdSet) {
            Order order = new Order();
            //Shipping address, name, phone number, store ID, user’s openID
            order.setAddress(orderParam.getAddress());
            order.setName(orderParam.getName());
            order.setPhone(orderParam.getPhone());
            order.setShopId(shopId);
            order.setOpenId(UserThreadLocal.get().get("openid").toString());
            //Insert the order and return the primary key, get the id of the order, and then insert the orderId and foodId into the orderFood table.
            orderMapper.insert(order);
            log.info("Test whether inserting the generated orderId primary key is successful: --order.id is{}",order.getId());
            //Traverse all the dishes sent from the front end and find the dishes in the current circulating store based on the shopId.
            for (OrderFoodParam orderFood : orderParam.getOrderFoods()) {
                //Among all the dishes in the order, find the dish in the current store and insert it into the orderFood table
                if(orderFood.getShopId()==shopId){
                    OrderFood of = new OrderFood();
                    of.setOrderId(order.getId());
                    of.setFoodId(orderFood.getId());
                    of.setCount(orderFood.getCount());
                    orderFoodService.save(of);
                }
            }
        }
        return Result.success("create orders success");
    }

    @Override
    public Result orderList() {
        //Get the openid of the current thread user
        String openid = (String) UserThreadLocal.get().get("openid");
        LambdaQueryWrapper<Order> qw = new LambdaQueryWrapper<>();
        //Query all orders based on openid, query orders that have not been deleted by the user, and sort by creation time
        qw.eq(Order::getAppDelete,false)
                .eq(Order::getOpenId,openid)
                .orderByDesc(Order::getCreated);
        List<Order> orderList = orderMapper.selectList(qw);
        //The order VoList finally returned to the front end
        List<OrderVo> orderVoList = new ArrayList<>();
        for (Order order : orderList) {
            OrderVo orderVo = new OrderVo();
            BeanUtils.copyProperties(order,orderVo);
            //Query shopName based on shopId and store it in orderVo
            orderVo.setShopName(shopService.getById(order.getShopId()).getShopName());
            LambdaQueryWrapper<OrderFood> orderFoodLambdaQueryWrapper = new LambdaQueryWrapper<>();
            //Query the dish IDs of all orders based on the order ID
            orderFoodLambdaQueryWrapper.eq(OrderFood::getOrderId,order.getId());
            //The following list contains id foodid orderid shopid
            List<OrderFood> orderFoodList = orderFoodService.list(orderFoodLambdaQueryWrapper);
            //The last order dish Vo stored in orderVo
            List<FoodVo> foodVos = new ArrayList<>();
            //Traverse the package foodVo, set the quantity, and other properties
            for (OrderFood orderFood : orderFoodList) {
                FoodVo foodVo = new FoodVo();
                //Set the quantity of dishes when placing an order
                foodVo.setCount(orderFood.getCount());
                Food food = foodService.getById(orderFood.getFoodId());
                BeanUtils.copyProperties(food,foodVo);
                foodVos.add(foodVo);

            }
            //Store the final dish vo in orderVo
            orderVo.setFoods(foodVos);
            //Store orderVo in list
            orderVoList.add(orderVo);
        }
        return Result.success(orderVoList);
    }

}
