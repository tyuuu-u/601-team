package com.shijiuAPI.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
//Order parameters, the dish list object passed in
public class OrderFoodParam {
    //foodId
    private Integer id;

    private Integer shopId;
    //quantity
    private Integer count;


}
