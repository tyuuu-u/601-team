package com.shijiuAPI.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shijiuAPI.pojo.Category;

public interface CateService extends IService<Category> {
}
