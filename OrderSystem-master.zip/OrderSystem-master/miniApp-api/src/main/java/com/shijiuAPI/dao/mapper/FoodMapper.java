package com.shijiuAPI.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiuAPI.pojo.Food;

public interface FoodMapper extends BaseMapper<Food> {
}
