package com.shijiuAPI.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.shijiuAPI.config.UserThreadLocal;
import com.shijiuAPI.pojo.Order;
import com.shijiuAPI.service.CommentService;
import com.shijiuAPI.service.OrderService;
import com.shijiuAPI.vo.Comment;
import com.shijiuAPI.vo.OrderFoodParam;
import com.shijiuAPI.vo.OrderParam;
import com.shijiuAPI.vo.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("order")
@Slf4j
public class OrderController {

    @Autowired
    private OrderService orderService;
    @Autowired
    private CommentService commentService;


    @PostMapping("create")
    public Result createOrder(@RequestBody OrderParam orderParam){
        log.info("sout OrderFoodParam from the front end{}",orderParam);
        log.info("Output the openid of threadlocal in the controller:{}", UserThreadLocal.get().get("openid"));
        orderService.createOrder(orderParam);
        return Result.success("ok");
    }

    @GetMapping("list")
    public Result orderList(){
        return orderService.orderList();
    }

    @GetMapping("delete/{id}")
    public Result removeById(@PathVariable("id") Integer id){
        Order order = new Order();
        order.setId(id);
        order.setAppDelete(true);
        return  Result.success(orderService.updateById(order));
    }

    @PostMapping("comment/{orderId}")
    public Result comment(@PathVariable("orderId")Integer orderId, @RequestBody Comment comment){
        Order order = new Order();
        order.setId(orderId);
        order.setCommented(true);
        if (comment.getContent()==""){
            comment.setContent("This user forgot to write a comment~~");
        }
       
        orderService.updateById(order);
        commentService.save(comment);
        log.info("Output orderID, output comment object---{}---{}",orderId,comment);
        return Result.success("received comments");
    }
}
