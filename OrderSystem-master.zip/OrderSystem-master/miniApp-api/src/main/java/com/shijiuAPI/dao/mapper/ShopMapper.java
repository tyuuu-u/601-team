package com.shijiuAPI.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiuAPI.pojo.Shop;

public interface ShopMapper extends BaseMapper<Shop> {
}
