package com.shijiuAPI.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiuAPI.pojo.Category;

public interface CateMapper extends BaseMapper<Category> {
}
