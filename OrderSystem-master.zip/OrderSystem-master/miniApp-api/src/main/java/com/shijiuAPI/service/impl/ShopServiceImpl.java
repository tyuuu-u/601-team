package com.shijiuAPI.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.shijiuAPI.dao.mapper.CateMapper;
import com.shijiuAPI.dao.mapper.FoodMapper;
import com.shijiuAPI.dao.mapper.ShopMapper;
import com.shijiuAPI.pojo.Category;
import com.shijiuAPI.pojo.Food;
import com.shijiuAPI.pojo.Shop;
import com.shijiuAPI.service.ShopService;
import com.shijiuAPI.vo.CateFoodsVo;
import com.shijiuAPI.vo.FoodVo;
import com.shijiuAPI.vo.Result;
import com.shijiuAPI.vo.ShopVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class ShopServiceImpl extends ServiceImpl<ShopMapper, Shop> implements ShopService {

    @Autowired
    private ShopMapper shopMapper;
    @Autowired
    private CateMapper cateMapper;
    @Autowired
    private FoodMapper foodMapper;


    @Override
    public Result shopList() {
        LambdaQueryWrapper<Shop> qw = new LambdaQueryWrapper<>();
        qw.eq(Shop::getClosed, false).eq(Shop::getIsShutDown, false).orderByDesc(Shop::getWeight);
        List<Shop> shops = shopMapper.selectList(qw);
        List<ShopVo> shopVos = new ArrayList<>();
        for (Shop shop : shops) {
            ShopVo shopVo = new ShopVo();
            BeanUtils.copyProperties(shop, shopVo);
            shopVos.add(shopVo);
        }
        log.info("sout shopvos {}", shopVos);
        return Result.success(shopVos);
    }

    @Override
    public Result cateFoodsList(Integer shopId) {
        //Find all categories of the store based on shopId
        LambdaQueryWrapper<Category> qw = new LambdaQueryWrapper<>();
        qw.eq(Category::getShopId, shopId);
        List<Category> categories = cateMapper.selectList(qw);
        //The last returned data cateFoodsList
        List<CateFoodsVo> res = new ArrayList<>();
        //Check to see if there are any recommended drinks today
        LambdaQueryWrapper<Food> recommendFoodQw = new LambdaQueryWrapper<>();
        //According to the store ID, query the store's recommended drinks today
        recommendFoodQw.eq(Food::getShopId, shopId).eq(Food::getIsRecommend, true);
        List<Food> recommendFoods = foodMapper.selectList(recommendFoodQw);
        //If there are recommended drinks, a new category will be generated,----Today's Recommendation--Category
        if (recommendFoods != null && recommendFoods.size() > 0) {
            //Encapsulate today’s recommended categories
            CateFoodsVo cateFoodsVo = new CateFoodsVo();
            cateFoodsVo.setCateName("Shopkeeper’s recommendation today");
            List<FoodVo> recommendFoodsVoList = new ArrayList<>();
            //Put today’s recommended drinks in vo
            for (Food recommendFood : recommendFoods) {
                FoodVo foodVo = new FoodVo();
                BeanUtils.copyProperties(recommendFood, foodVo);
                recommendFoodsVoList.add(foodVo);
            }
            //Encapsulate today’s recommended classification-drink list
            cateFoodsVo.setFoods(recommendFoodsVoList);
            res.add(cateFoodsVo);
        }

        //There is no recommendation today. Query all drinks according to category, and then package cateFoodVo
        for (Category category : categories) {
            CateFoodsVo cateFoodsVo = new CateFoodsVo();
            cateFoodsVo.setCateId(category.getId());
            cateFoodsVo.setCateName(category.getName());
            //Query all foods based on category id
            LambdaQueryWrapper<Food> foodQw = new LambdaQueryWrapper<>();
            foodQw.eq(Food::getCategoryId, category.getId());
            List<Food> foods = foodMapper.selectList(foodQw);
            List<FoodVo> foodsVoList = new ArrayList<>();
            for (Food food : foods) {
                FoodVo foodVo = new FoodVo();
                BeanUtils.copyProperties(food, foodVo);
                foodsVoList.add(foodVo);
            }
            cateFoodsVo.setFoods(foodsVoList);
            res.add(cateFoodsVo);
        }
        return Result.success(res);
    }
}
