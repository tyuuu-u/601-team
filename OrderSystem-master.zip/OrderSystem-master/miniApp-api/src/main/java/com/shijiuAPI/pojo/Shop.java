package com.shijiuAPI.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Shop {

    //store id
    @TableId( type = IdType.AUTO)
    Integer id;
    //Store owner id
    Integer userId;
    //Shopkeeper's name
    String ownerName;

    String shopName;

    String shopSrc;
    //Store contact information
    String phone;
    //Store introduction
    String summary;
    //Store rating, administrator control
    Integer stars;
    //Store weight, controlled by administrator
    Integer weight;
    //Whether it is open or not is controlled by the store owner.
    Boolean closed;
    //Whether to add or remove the store is controlled by the administrator.
    Boolean isShutDown;

}
