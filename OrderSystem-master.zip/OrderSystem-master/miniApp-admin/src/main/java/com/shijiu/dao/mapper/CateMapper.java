package com.shijiu.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiu.pojo.Category;

public interface CateMapper extends BaseMapper<Category> {
}
