package com.shijiu.controller;

import com.shijiu.pojo.Order;
import com.shijiu.service.OrderService;
import com.shijiu.utils.UserThreadLocal;
import com.shijiu.vo.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("order")
@Slf4j
public class OrderController {

    @Autowired
    private OrderService orderService;


    //Query order list
    @GetMapping("orderlist")
    public Result getOrderList(){
        return orderService.selectOrderList((Integer) UserThreadLocal.get().get("shopId"));
    }

    //Modify order status
    @PostMapping("update")
    public Result updateStatus(@RequestBody Order order){
        return orderService.updateStatus(order);
    }
    //Tombstone order
    @GetMapping("delete/{id}")
    public Result deleteOrder(@PathVariable("id") Integer id){
        Order order = new Order();
        order.setId(id);
        order.setAdminDelete(true);
        orderService.updateById(order);
        return Result.success("Order deleted successfully");
    }

    //View order details - View all dishes and quantities of the order based on the order ID
    @GetMapping("showfood/{id}")
    public Result showOrderFood(@PathVariable("id") Integer id){

        return orderService.showFood(id);
    }
}
