package com.shijiu.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shijiu.pojo.OrderFood;

public interface OrderFoodService extends IService<OrderFood> {
}
