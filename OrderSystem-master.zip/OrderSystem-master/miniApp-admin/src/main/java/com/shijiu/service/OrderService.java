package com.shijiu.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shijiu.pojo.Order;
import com.shijiu.vo.Result;


public interface OrderService extends IService<Order> {

    //Query all orders in the store based on store ID
    Result selectOrderList(Integer id);

    //Update order status
    Result updateStatus(Order order);

    //Show everything about the order
    Result showFood(Integer id);
}
