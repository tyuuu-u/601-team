package com.shijiu.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiu.pojo.TimeTest;

public interface TestMapper extends BaseMapper<TimeTest> {
}
