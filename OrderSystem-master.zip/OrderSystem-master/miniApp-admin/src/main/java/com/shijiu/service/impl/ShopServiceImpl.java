package com.shijiu.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.shijiu.dao.mapper.ShopMapper;
import com.shijiu.pojo.Shop;
import com.shijiu.pojo.User;
import com.shijiu.service.ShopService;
import com.shijiu.service.UserService;
import com.shijiu.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ShopServiceImpl extends ServiceImpl<ShopMapper,Shop> implements ShopService {

    @Autowired
    private ShopMapper shopMapper;
    @Autowired
    private UserService userService;

    /**
     * Query stores based on user ID
     * 1. Check whether this person has registered a store (one person only has one store)
     * 2. When the login is successful, the person's store is found and returned to the front end.
     * @param userId shop owner id
     * @return Return to the owner's shop
     */
    @Override
    public Shop selectShopByUserId(Integer userId) {
        LambdaQueryWrapper<Shop> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Shop::getUserId,userId).select(Shop::getId).last("limit 1 ");
        return shopMapper.selectOne(lambdaQueryWrapper);
    }

    @Override
    public Result saveShop(Shop shop) {
        LambdaQueryWrapper<Shop> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Shop::getUserId,shop.getUserId());
        Shop resShop = shopMapper.selectOne(lambdaQueryWrapper);
        if(shop.getUserId() == 1){
            return Result.fail(444,"Cannot register using administrator account");
        }
        //Use the received userid to query the store. If it already exists, an error will be returned.
        if (resShop != null){
            return Result.fail(444,"This store owner number has been bound to the store, please enter the correct number");
        }
        //Check if userid exists
        LambdaQueryWrapper<User> userQw = new LambdaQueryWrapper<>();
        User resUser = userService.getById(shop.getUserId());
        if(resUser == null){
            return Result.fail(777,"This store owner number does not exist, please enter the correct store owner number");
        }
        //userid does not exist in the shop table && userid exists in the user table, which means that userid has not registered a store yet, just insert it directly
        return Result.success(shopMapper.insert(shop));
    }
}
