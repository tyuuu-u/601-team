package com.shijiu.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiu.pojo.Comment;

public interface CommentMapper extends BaseMapper<Comment> {
}
