package com.shijiu.vo;

import lombok.Data;

@Data
public class PageParams {

    private Integer page;

    private Integer pageSize;

    private Integer total;
}
