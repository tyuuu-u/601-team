package com.shijiu.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shijiu.pojo.User;

import java.util.List;

public interface UserService extends IService<User> {

    /**
     *  Query users based on account password
     * @param username Login account
     * @param password Login password
     * @return Return the User queried from the database
     */
    User loginFindUser(String username, String password);


}
