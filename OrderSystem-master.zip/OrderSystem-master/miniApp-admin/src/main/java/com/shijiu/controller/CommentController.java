package com.shijiu.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.shijiu.pojo.Comment;
import com.shijiu.service.CommentService;
import com.shijiu.utils.UserThreadLocal;
import com.shijiu.vo.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("comment")
@Slf4j
public class CommentController {

    @Autowired
    private CommentService commentService;

    @GetMapping("list")
    public Result getCommentList(){
        LambdaQueryWrapper<Comment> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Comment::getShopId, UserThreadLocal.get().get("shopId")).orderByDesc(Comment::getCreateDate);
        List<Comment> list = commentService.list(lambdaQueryWrapper);
        log.info("Check out the list of comments{}",list);
        return Result.success(list);
    }


    //Reply to review Owner
    @PostMapping("update")
    public Result updateComment(@RequestBody Comment comment){
        comment.setIsReply(true);
        return Result.success(commentService.updateById(comment));
    }

 
}
