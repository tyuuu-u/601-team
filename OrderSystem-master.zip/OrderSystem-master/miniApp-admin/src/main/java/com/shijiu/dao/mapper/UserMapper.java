package com.shijiu.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiu.pojo.User;

public interface UserMapper extends BaseMapper<User> {
}
