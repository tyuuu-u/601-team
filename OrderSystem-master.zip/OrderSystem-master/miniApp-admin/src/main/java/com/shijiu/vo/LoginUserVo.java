package com.shijiu.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginUserVo {
    Integer userId;

    Integer shopId;

    // 1 is the administrator, 0 is the store owner
    Boolean isAdmin;


}
