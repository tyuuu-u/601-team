package com.shijiu.service;

import com.shijiu.params.LoginParam;
import com.shijiu.pojo.User;
import com.shijiu.vo.Result;

import javax.servlet.http.HttpServletRequest;

public interface LoginService {

    /**
     * Login function
     * @param loginParam
     * @return
     */
    Result login(LoginParam loginParam);

    /**
     * Obtain user information after successful login
     * @param token Need to bring token
     * @return
     */
    Result loginUserInfo(String token);

    User checkToken(String token);

    /**
     * Log out
     * @param token
     * @return
     */
    Result logout(String token, HttpServletRequest httpServletRequest);

    /**
     * register
     * @param loginParam
     * @return
     */
    Result register(LoginParam loginParam);
}
