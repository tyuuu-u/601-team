package com.shijiu.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class FoodListVo {

    //How many dishes are there in this store?
    private Long total;
    //Dishes vo
    private List<FoodVo> foodVoList;
}
