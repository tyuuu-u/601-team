package com.shijiu.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shijiu.pojo.Shop;

public interface ShopMapper extends BaseMapper<Shop> {
}
