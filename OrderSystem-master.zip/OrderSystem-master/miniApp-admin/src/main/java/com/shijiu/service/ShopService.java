package com.shijiu.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shijiu.pojo.Shop;
import com.shijiu.vo.Result;

public interface ShopService extends IService<Shop> {

    /**
     * Query store id based on user id
     *1. Check whether this person has registered a store (one person only has one store)
     *2. When the login is successful, the person's store ID is found and returned to the front end.
     * @param userId shop owner id
     * @return Returns the shop owner's shop id
     */
    Shop selectShopByUserId(Integer userId);

    Result saveShop(Shop shop);
}
