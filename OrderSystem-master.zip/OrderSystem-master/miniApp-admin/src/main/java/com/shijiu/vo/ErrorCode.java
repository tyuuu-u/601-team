package com.shijiu.vo;

public enum  ErrorCode {

    PARAMS_ERROR(10001,"Wrong parameters"),
    ACCOUNT_PWD_NOT_EXIST(10002,"Username or password does not exist"),
    TOKEN_ERROR(10003,"token is illegal"),
    ACCOUNT_EXIST(10004,"Account already exists"),
    NO_PERMISSION(70001,"No access"),
    SESSION_TIME_OUT(90001,"Session timeout"),
    NO_LOGIN(90002,"Not logged in"),;

    private int code;
    private String message;

    ErrorCode(int code, String message){
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}