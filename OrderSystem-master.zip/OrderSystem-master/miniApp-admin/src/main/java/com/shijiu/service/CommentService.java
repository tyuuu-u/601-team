package com.shijiu.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shijiu.pojo.Comment;

public interface CommentService extends IService<Comment> {
}
