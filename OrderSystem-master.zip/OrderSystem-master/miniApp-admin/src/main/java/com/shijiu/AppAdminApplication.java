package com.shijiu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppAdminApplication {
    public static void main(String[] args) {
        SpringApplication.run(AppAdminApplication.class,args);
    }
}
