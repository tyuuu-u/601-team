package com.shijiu.handler;

import com.alibaba.fastjson.JSON;
import com.shijiu.pojo.User;
import com.shijiu.service.LoginService;
import com.shijiu.utils.JWTUtils;
import com.shijiu.utils.UserThreadLocal;
import com.shijiu.vo.ErrorCode;
import com.shijiu.vo.Result;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.plugin.Interceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@Component
public class LoginInterceptor implements HandlerInterceptor {

    @Autowired
    private LoginService loginService;
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (!(handler instanceof HandlerMethod)){
            //The handler may be RequestResourceHandler. The springboot program accesses static resources. By default, it goes to the static directory under the classpath to query.
            return true;
        }
        String token = request.getHeader("token");

        if (StringUtils.isBlank(token)){
            Result result = Result.fail(ErrorCode.NO_LOGIN.getCode(), "Not logged in");
            response.setContentType("application/json;charset=utf-8");
            response.getWriter().print(JSON.toJSONString(result));
            return false;
        }
        //The map contains the userId and shopId that are inserted into the token when logging in, which are inserted into the login service.
        Map<String, Object> map = JWTUtils.checkToken(token);
        //Store the map in threadlocal so that you can get the userId and shopId later.
        UserThreadLocal.put(map);
        //Release directly
        return true;
    }
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        UserThreadLocal.remove();
    }
}
