package com.shijiu.utils;


import com.qcloud.cos.COSClient;
import com.qcloud.cos.ClientConfig;
import com.qcloud.cos.auth.BasicCOSCredentials;
import com.qcloud.cos.auth.COSCredentials;
import com.qcloud.cos.exception.CosClientException;
import com.qcloud.cos.exception.CosServiceException;
import com.qcloud.cos.http.HttpProtocol;
import com.qcloud.cos.model.ObjectMetadata;
import com.qcloud.cos.model.PutObjectRequest;
import com.qcloud.cos.model.PutObjectResult;
import com.qcloud.cos.model.UploadResult;
import com.qcloud.cos.region.Region;
import com.qcloud.cos.transfer.TransferManager;
import com.qcloud.cos.transfer.Upload;
import org.apache.logging.log4j.core.util.FileUtils;
import org.aspectj.util.FileUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
public class CosUploadUtils {

    public static final String url = "http://food-1309527051.cos.ap-guangzhou.myqcloud.com/";

    @Value("${cos_SecretId}")
    private String cosSecretId;

    @Value("${cos_SecretKey}")
    private String cosSecretKey;

    @Value("${cos_APPID}")
    private String cosAPPID;

    @Value("${cos_Bucket}")
    private String cosBucket;

    @Value("${cos_Region}")
    private String cosRegion;

    public boolean upload(MultipartFile multipartFile) {
        // To use the high-level interface, you must first ensure that there is a TransferManager instance in this process. If not, create one.
// For detailed code, see this page: Advanced Interface -> Create TransferManager
        TransferManager transferManager = createTransferManager();

        ObjectMetadata objectMetadata = new ObjectMetadata();
// If the uploaded stream can obtain the accurate stream length, it is recommended to fill in content-length.
// If there is really no way to obtain it, the following line can be omitted, but at the same time, the advanced interface cannot use multi-part upload.
// objectMetadata.setContentLength(inputStreamLength);
// The object key (Key) is the unique identifier of the object in the bucket.
        String key = multipartFile.getOriginalFilename();

        try {
            // The high-level interface will return an asynchronous result Upload
            // The waitForUploadResult method can be called synchronously to wait for the upload to complete. It will return UploadResult successfully, and throw an exception if it fails.
            PutObjectRequest putObjectRequest = new PutObjectRequest(cosBucket, key, multipartFile.getInputStream(), objectMetadata);
            Upload upload = transferManager.upload(putObjectRequest);
            UploadResult uploadResult = upload.waitForUploadResult();
            shutdownTransferManager(transferManager);
            return true;
        } catch (CosServiceException e) {
            e.printStackTrace();
        } catch (CosClientException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

// After confirming that this process no longer uses the transferManager instance, close it
// For detailed code, please refer to this page: Advanced interface -> Close TransferManager

        return false;
    }

    TransferManager createTransferManager() {
        // Create a COSClient instance, which is the basic instance for accessing COS services.
        // See this page for detailed code: Simple operation -> Create COSClient
        COSClient cosClient = createCOSClient();

        // Customize the thread pool size. It is recommended to set it to 16 or 32 when the network between the client and COS is sufficient (for example, using Tencent Cloud's CVM to upload COS in the same region), which can make full use of network resources.
        // For situations where public network transmission is used and the network bandwidth quality is not high, it is recommended to reduce this value to avoid request timeout due to too slow network speed.
        ExecutorService threadPool = Executors.newFixedThreadPool(32);

        // Pass in a threadpool. If no thread pool is passed in, a single-threaded thread pool will be generated in TransferManager by default.
        TransferManager transferManager = new TransferManager(cosClient, threadPool);

//        // Set configuration items for advanced interfaces
//           Chunked upload threshold and chunk size are 5MB and 1MB respectively
//        TransferManagerConfiguration transferManagerConfiguration = new TransferManagerConfiguration();
//        transferManagerConfiguration.setMultipartUploadThreshold(5*1024*1024);
//        transferManagerConfiguration.setMinimumUploadPartSize(1*1024*1024);
//        transferManager.setConfiguration(transferManagerConfiguration);

        return transferManager;
    }

    // Create a COSClient instance, which is used for subsequent call requests
    COSClient createCOSClient() {
        // Set user identity information.
        // SECRETID and SECRETKEY Please log in to the management console https://console.cloud.tencent.com/cam/capi to view and manage
        String secretId = cosSecretId;
        String secretKey = cosSecretKey;
        COSCredentials cred = new BasicCOSCredentials(secretId, secretKey);

        // ClientConfig contains client settings for subsequent COS requests:
        ClientConfig clientConfig = new ClientConfig();

        // Set bucket region
        // COS_REGION Please refer to https://cloud.tencent.com/document/product/436/6224
        clientConfig.setRegion(new Region(cosRegion));

        // Set request protocol, http or https
        // For versions 5.6.53 and lower, it is recommended to use the https protocol.
        // 5.6.54 and higher, https is used by default
        clientConfig.setHttpProtocol(HttpProtocol.http);

        //The following settings are optional:

        //Set socket read timeout, default 30s
        clientConfig.setSocketTimeout(30 * 1000);
        // Set connection establishment timeout, default 30s
        clientConfig.setConnectionTimeout(30 * 1000);

        //If necessary, set http proxy, ip and port
//        clientConfig.setHttpProxyIp("httpProxyIp");
//        clientConfig.setHttpProxyPort(80);

        // Generate cos client.
        return new COSClient(cred, clientConfig);
    }

    void shutdownTransferManager(TransferManager transferManager) {
        // If the specified parameter is true, the COSClient instance inside transferManager will also be closed.
        // If the specified parameter is false, the COSClient instance inside transferManager will not be closed.
        transferManager.shutdownNow(true);
    }
}
